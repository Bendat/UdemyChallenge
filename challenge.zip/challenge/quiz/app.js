requirejs.config({
    baseUrl: '/challenge/quiz/',
    paths: {
        "knockout": 'bower_components/knockout/dist/knockout',
        "app": "public/build/app"
    }
});