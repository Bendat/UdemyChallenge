//typescript --outFile amd modules are not compatible with requireJs. Attempts to emulate a single outFile.
export {MainViewModel} from "public/build/MainViewModel";
export {Quiz} from "public/build/quiz";
